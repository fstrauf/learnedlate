#!/bin/bash

# Quick setup verification script

echo ""
echo "🔍 Checking SEO Workflow Setup..."
echo ""

# Check key directories
echo "Checking directories..."
dirs=(
  ".github/prompts"
  "general/shared"
  "general/example_project"
  "projects/seo/templates"
  "mcp/seo-mcp"
  "mcp/seo-content-mcp"
  "config"
)

for dir in "${dirs[@]}"; do
  if [[ -d "$dir" ]]; then
    echo "  ✓ $dir"
  else
    echo "  ✗ $dir (missing)"
  fi
done

echo ""
echo "Checking files..."
files=(
  "README.md"
  "setup.sh"
  ".github/prompts/_seo1-template.prompt.md"
  ".github/prompts/_seo2-template.prompt.md"
  ".github/prompts/_seo3-template.prompt.md"
  ".github/prompts/_seo4-template.prompt.md"
  "general/shared/ARTICLES_TEMPLATE.json"
  "general/shared/brandvoice_template.md"
  "projects/seo/templates/content_brief_template.md"
  "projects/seo/1-keyword_research.md"
  "projects/seo/2-content_creation.md"
  "projects/seo/3-clustering_linking.md"
  "projects/seo/4-content_cleanup.md"
  "general/example_project/articles.json"
  "config/copilot_mcp_config.template.md"
)

for file in "${files[@]}"; do
  if [[ -f "$file" ]]; then
    echo "  ✓ $file"
  else
    echo "  ✗ $file (missing)"
  fi
done

echo ""
echo "Setup verification complete!"
echo ""
