#!/bin/bash

# SEO Workflow - Interactive Setup Script
# This script creates a new project and sets everything up automatically

set -e  # Exit on error

echo ""
echo "════════════════════════════════════════════"
echo "  🚀 SEO Workflow Setup"
echo "════════════════════════════════════════════"
echo ""

# Get project details
read -p "Project name (e.g., coffee, real-estate): " PROJECT_NAME
read -p "Website URL (e.g., coffee-blog.com): " WEBSITE_URL
read -p "CapSolver API key (optional, press Enter to skip): " CAPSOLVER_KEY

# Validate project name
if [[ -z "$PROJECT_NAME" ]]; then
    echo "❌ Project name cannot be empty"
    exit 1
fi

# Check if project already exists
if [[ -d "general/$PROJECT_NAME" ]]; then
    read -p "⚠️  Project '$PROJECT_NAME' already exists. Overwrite? (y/N): " CONFIRM
    if [[ "$CONFIRM" != "y" ]]; then
        echo "Cancelled."
        exit 0
    fi
fi

echo ""
echo "Creating project structure..."

# 1. Create directories
mkdir -p "general/$PROJECT_NAME/content"

# 2. Create content_brief from template
echo "  Creating content brief..."
sed "s/\[PROJECT_NAME\]/$PROJECT_NAME/g; s/\[WEBSITE_URL\]/$WEBSITE_URL/g" \
    "projects/seo/templates/content_brief_template.md" > \
    "general/$PROJECT_NAME/${PROJECT_NAME}_seo_content_brief.md"

# 3. Create articles.json from template
echo "  Creating articles registry..."
sed "s/\[PROJECT_NAME\]/$PROJECT_NAME/g" \
    "general/shared/ARTICLES_TEMPLATE.json" > \
    "general/$PROJECT_NAME/articles.json"

# 4. Create manifest.json
echo "  Creating manifest..."
cat > "general/$PROJECT_NAME/manifest.json" << EOF
{
  "project_name": "$PROJECT_NAME",
  "website_url": "$WEBSITE_URL",
  "capsolver_key": "$CAPSOLVER_KEY",
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF

# 5. Create project overview file
echo "  Creating project overview..."
cat > "general/$PROJECT_NAME/${PROJECT_NAME}.md" << EOF
# $PROJECT_NAME

**Website:** $WEBSITE_URL

## Project Overview

Add your project details here.

### Target Audience

Who are you creating content for?

### Key Topics

What are the main topics?

### Publishing Schedule

How often do you publish?

---

See \`${PROJECT_NAME}_seo_content_brief.md\` for the full content strategy.
EOF

# 6. Copy and substitute prompts
echo "  Creating prompts..."
for i in 1 2 3 4; do
    sed "s/\[PROJECT_NAME\]/$PROJECT_NAME/g; s/\[WEBSITE_URL\]/$WEBSITE_URL/g" \
        ".github/prompts/_seo${i}-template.prompt.md" > \
        ".github/prompts/seo${i}-${PROJECT_NAME}.prompt.md"
done

# 7. Install/update MCPs (if requirements.txt exists)
echo ""
echo "Installing MCPs..."

# Detect installer: uv for speed, pip as fallback
INSTALLER="pip"
if command -v uv &> /dev/null; then
    INSTALLER="uv pip"
fi

# Install SEO MCP dependencies
if [[ -f "mcp/seo-mcp/requirements.txt" ]]; then
    echo "  Installing SEO MCP dependencies..."
    if $INSTALLER install -q -r "mcp/seo-mcp/requirements.txt" 2>/dev/null; then
        echo "  ✓ SEO MCP installed"
    else
        echo "  ⚠ SEO MCP installation had issues (MCPs may still work)"
    fi
fi

# Install SEO Content MCP dependencies
if [[ -f "mcp/seo-content-mcp/requirements.txt" ]]; then
    echo "  Installing SEO Content MCP dependencies..."
    if $INSTALLER install -q -r "mcp/seo-content-mcp/requirements.txt" 2>/dev/null; then
        echo "  ✓ SEO Content MCP installed"
    else
        echo "  ⚠ SEO Content MCP installation had issues (MCPs may still work)"
    fi
fi

# 8. Show next steps
echo ""
echo "════════════════════════════════════════════"
echo "  ✅ Project Created!"
echo "════════════════════════════════════════════"
echo ""
echo "📁 Project location:"
echo "   general/$PROJECT_NAME/"
echo ""
echo "📝 Your prompts:"
echo "   .github/prompts/seo1-${PROJECT_NAME}.prompt.md  (research)"
echo "   .github/prompts/seo2-${PROJECT_NAME}.prompt.md  (create)"
echo "   .github/prompts/seo3-${PROJECT_NAME}.prompt.md  (link)"
echo "   .github/prompts/seo4-${PROJECT_NAME}.prompt.md  (cleanup)"
echo ""
echo "⚙️  Important: Maintain your project file"
echo "   The system requires you to update and maintain:"
echo "   general/$PROJECT_NAME/${PROJECT_NAME}.md"
echo ""
echo "   This file contains your project details, brand voice, and context."
echo "   Keeping it updated ensures the prompts and MCPs work correctly."
echo ""
echo "🔧 Next step: Configure MCPs in GitHub Copilot"
echo ""
echo "1. Open your Copilot config file:"
echo "   ~/.copilot/config.toml"
echo ""
echo "2. Add this section (replace PROJECT_ROOT with your folder path):"
echo ""
echo "   [[mcp_server]]"
echo "   name = \"seo-mcp\""
echo "   command = \"python -m mcp.server.stdio\""
echo "   args = [\"--tool\", \"seo\"]"
echo "   env = { SEO_MCP_PATH = \"PROJECT_ROOT/mcp/seo-mcp\" }"
echo ""
echo "   [[mcp_server]]"
echo "   name = \"seo-content-mcp\""
echo "   command = \"python -m mcp.server.stdio\""
echo "   args = [\"--tool\", \"content\"]"
echo "   env = { CONTENT_MCP_PATH = \"PROJECT_ROOT/mcp/seo-content-mcp\" }"
echo ""
echo "3. Restart GitHub Copilot"
echo ""
echo "4. Run your first workflow:"
echo "   - Open the .github/prompts/ folder in your editor"
echo "   - In GitHub Copilot, type: / (forward slash)"
echo "   - Select seo1-${PROJECT_NAME}.prompt.md"
echo "   - Copilot will load and run the entire prompt"
echo ""
echo "   (No need to copy/paste — the prompt files are already accessible)"
echo ""
echo "Questions? See README.md"
echo ""
