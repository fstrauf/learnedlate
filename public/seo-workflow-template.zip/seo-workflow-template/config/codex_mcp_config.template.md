# SEO Workflow - GitHub Copilot MCP Configuration Template

Add these sections to your ~/.copilot/config.toml file.

Replace `PROJECT_ROOT` with the full path to your seo-workflow-template folder.

## Full MCP Configuration

```toml
[[mcp_server]]
name = "seo-mcp"
command = "python"
args = ["-m", "mcp.server.stdio"]
type = "stdio"

[mcp_server.env]
SEO_MCP_PATH = "PROJECT_ROOT/mcp/seo-mcp"
# Optional: Add your CapSolver API key here
# CAPSOLVER_API_KEY = "your-key-here"

[[mcp_server]]
name = "seo-content-mcp"
command = "python"
args = ["-m", "mcp.server.stdio"]
type = "stdio"

[mcp_server.env]
CONTENT_MCP_PATH = "PROJECT_ROOT/mcp/seo-content-mcp"
```

## How to Apply

1. Open `~/.copilot/config.toml` in your editor
2. Find the `[[mcp_server]]` sections
3. Add the above configurations
4. Replace `PROJECT_ROOT` with actual path (e.g., `/Users/yourname/seo-workflow-template`)
5. Save the file
6. Restart GitHub Copilot

## Example (Full Path)

```toml
[[mcp_server]]
name = "seo-mcp"
command = "python"
args = ["-m", "mcp.server.stdio"]
type = "stdio"

[mcp_server.env]
SEO_MCP_PATH = "/Users/yourname/seo-workflow-template/mcp/seo-mcp"

[[mcp_server]]
name = "seo-content-mcp"
command = "python"
args = ["-m", "mcp.server.stdio"]
type = "stdio"

[mcp_server.env]
CONTENT_MCP_PATH = "/Users/yourname/seo-workflow-template/mcp/seo-content-mcp"
```

## Verify Installation

After restarting Codex:

1. Open any prompt from `.github/prompts/`
2. Try running it
3. If MCPs work, the prompt will complete successfully
4. If there's an error, check the Codex logs for details
