---
mode: agent
---

# newtest - Content Creation

Execute the SEO content creation workflow from the projects/seo/2-content_creation.md file using the newtest project files.

## Project Files

- **Project folder:** general/newtest/
- **Project overview:** general/newtest/newtest.md
- **Content brief:** general/newtest/newtest_seo_content_brief.md
- **Articles list:** general/newtest/articles.json
- **Content folder:** general/newtest/content/
- **Brand voice:** general/shared/brandvoice_template.md
- **Article template:** projects/seo/templates/article_template.md

## Workflow Reference

Follow the complete workflow from: projects/seo/2-content_creation.md

## Key Details

- **Website:** newsite.com
- **Goal:** Write high-quality SEO articles based on keyword research

## Instructions

1. Read the articles.json to see which keywords need content
2. Follow the workflow steps in 2-content_creation.md
3. Review the brand voice guide for tone and style
4. Write articles using the article template structure
5. Save each article to content/[NUMBER]_article-title.md
6. Update articles.json with word counts and status
7. Ensure articles match target keyword intent

## MCPs Available

- **seo-content-mcp**: Content validation and metadata management

Use this MCP to validate your articles as you create them.
