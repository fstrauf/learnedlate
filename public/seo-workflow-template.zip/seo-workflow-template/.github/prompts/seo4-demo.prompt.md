---
mode: agent
---

# demo - Content Cleanup

Execute the content validation and cleanup workflow from the projects/seo/4-content_cleanup.md file.

## Project Files

- **Project folder:** general/demo/
- **Content folder:** general/demo/content/
- **Articles list:** general/demo/articles.json
- **Manifest:** general/demo/manifest.json

## Workflow Reference

Follow the complete workflow from: projects/seo/4-content_cleanup.md

## Key Details

- **Website:** demo.com
- **Goal:** Validate, clean, and finalize all content for publication

## Instructions

1. Follow the workflow steps in 4-content_cleanup.md
2. Validate all articles using the SEO Content MCP
3. Check for:
   - Duplicate headings
   - Missing metadata
   - Broken internal links
   - Date consistency
   - Word count targets
4. Fix any issues found
5. Ensure articles.json is clean and complete
6. Distribute publication dates evenly
7. Mark articles as ready for publication

## MCPs Available

- **seo-content-mcp**: Full validation suite
  - Validate content files
  - Check date distribution
  - Clean metadata
  - Fix relationships

Use this MCP to validate and clean everything.
