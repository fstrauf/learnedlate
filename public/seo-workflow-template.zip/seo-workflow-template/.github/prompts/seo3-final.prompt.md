---
mode: agent
---

# final - Clustering & Linking

Execute the clustering and internal linking workflow from the projects/seo/3-clustering_linking.md file.

## Project Files

- **Project folder:** general/final/
- **Content folder:** general/final/content/
- **Articles list:** general/final/articles.json

## Workflow Reference

Follow the complete workflow from: projects/seo/3-clustering_linking.md

## Key Details

- **Website:** final.com
- **Goal:** Create topic clusters and add internal linking between articles

## Instructions
