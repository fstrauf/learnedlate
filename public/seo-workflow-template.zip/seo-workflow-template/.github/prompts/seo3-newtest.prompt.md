---
mode: agent
---

# newtest - Clustering & Linking

Execute the clustering and internal linking workflow from the projects/seo/3-clustering_linking.md file.

## Project Files

- **Project folder:** general/newtest/
- **Content folder:** general/newtest/content/
- **Articles list:** general/newtest/articles.json

## Workflow Reference

Follow the complete workflow from: projects/seo/3-clustering_linking.md

## Key Details

- **Website:** newsite.com
- **Goal:** Create topic clusters and add internal linking between articles

## Instructions
