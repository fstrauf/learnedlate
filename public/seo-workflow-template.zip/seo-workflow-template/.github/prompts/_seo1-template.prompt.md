---
mode: agent
---

# [PROJECT_NAME] - SEO Keyword Research

Execute the SEO keyword research workflow from the projects/seo/1-keyword_research.md file using the [PROJECT_NAME] project files.

## Project Files

- **Project folder:** general/[PROJECT_NAME]/
- **Project overview:** general/[PROJECT_NAME]/[PROJECT_NAME].md
- **Content brief:** general/[PROJECT_NAME]/[PROJECT_NAME]_seo_content_brief.md
- **Articles list:** general/[PROJECT_NAME]/articles.json
- **Content folder:** general/[PROJECT_NAME]/content/
- **Brand voice:** general/shared/brandvoice_template.md

## Workflow Reference

Follow the complete workflow from: projects/seo/1-keyword_research.md

## Key Details

- **Website:** [WEBSITE_URL]
- **Goal:** Research and identify SEO opportunities

## Instructions

1. Read the project overview to understand context
2. Follow the workflow steps in 1-keyword_research.md
3. Use the SEO MCP to research keywords and analyze competitors
4. Update the content brief with opportunities
5. Populate articles.json with keywords and initial research
6. Save all findings

## MCPs Available

- **seo-mcp**: Keyword research, traffic data, backlink analysis (requires CapSolver key for traffic)
- **seo-content-mcp**: Content validation and management

Use these MCPs to gather data and validate your research.
