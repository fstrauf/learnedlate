---
mode: agent
---

# [PROJECT_NAME] - Clustering & Linking

Execute the clustering and internal linking workflow from the projects/seo/3-clustering_linking.md file.

## Project Files

- **Project folder:** general/[PROJECT_NAME]/
- **Content folder:** general/[PROJECT_NAME]/content/
- **Articles list:** general/[PROJECT_NAME]/articles.json

## Workflow Reference

Follow the complete workflow from: projects/seo/3-clustering_linking.md

## Key Details

- **Website:** [WEBSITE_URL]
- **Goal:** Create topic clusters and add internal linking between articles

## Instructions
