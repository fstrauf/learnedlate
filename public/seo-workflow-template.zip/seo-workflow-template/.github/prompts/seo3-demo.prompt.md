---
mode: agent
---

# demo - Clustering & Linking

Execute the clustering and internal linking workflow from the projects/seo/3-clustering_linking.md file.

## Project Files

- **Project folder:** general/demo/
- **Content folder:** general/demo/content/
- **Articles list:** general/demo/articles.json

## Workflow Reference

Follow the complete workflow from: projects/seo/3-clustering_linking.md

## Key Details

- **Website:** demo.com
- **Goal:** Create topic clusters and add internal linking between articles

## Instructions
