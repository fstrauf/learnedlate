---
mode: agent
---

# [PROJECT_NAME] - Content Creation

Execute the SEO content creation workflow from the projects/seo/2-content_creation.md file using the [PROJECT_NAME] project files.

## Project Files

- **Project folder:** general/[PROJECT_NAME]/
- **Project overview:** general/[PROJECT_NAME]/[PROJECT_NAME].md
- **Content brief:** general/[PROJECT_NAME]/[PROJECT_NAME]_seo_content_brief.md
- **Articles list:** general/[PROJECT_NAME]/articles.json
- **Content folder:** general/[PROJECT_NAME]/content/
- **Brand voice:** general/shared/brandvoice_template.md
- **Article template:** projects/seo/templates/article_template.md

## Workflow Reference

Follow the complete workflow from: projects/seo/2-content_creation.md

## Key Details

- **Website:** [WEBSITE_URL]
- **Goal:** Write high-quality SEO articles based on keyword research

## Instructions

1. Read the articles.json to see which keywords need content
2. Follow the workflow steps in 2-content_creation.md
3. Review the brand voice guide for tone and style
4. Write articles using the article template structure
5. Save each article to content/[NUMBER]_article-title.md
6. Update articles.json with word counts and status
7. Ensure articles match target keyword intent

## MCPs Available

- **seo-content-mcp**: Content validation and metadata management

Use this MCP to validate your articles as you create them.
