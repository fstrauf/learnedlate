"""
SEO MCP - A FastMCP service for retrieving SEO information for any domain using Ahrefs' data.
"""

__version__ = "0.2.4"
