"""
SEO MCP Server: A free SEO tool MCP (Model Control Protocol) service based on Ahrefs data. Includes features such as backlinks, keyword ideas, and more.
"""
import requests
import time
import os
import urllib.parse
import json
from typing import Dict, List, Optional, Any, Literal

from fastmcp import FastMCP

from seo_mcp.backlinks import get_backlinks, load_signature_from_cache, get_signature_and_overview
from seo_mcp.keywords import get_keyword_difficulty
from seo_mcp.traffic import check_traffic


def custom_serializer(data: Any) -> str:
    """
    Custom tool serializer to ensure proper serialization of return values.
    For string returns, pass through as-is. For other types, JSON serialize.
    This prevents FastMCP from wrapping strings in extra serialization.
    
    Reference: FastMCP 2.13.0rc2 Custom Tool Serialization
    https://docs.glama.ai/fastmcp/servers/server#custom-tool-serialization
    """
    if isinstance(data, str):
        return data
    return json.dumps(data)


# Initialize FastMCP with proper configuration:
# - strict_input_validation=False: Use flexible validation (Pydantic coercion) instead of strict JSON Schema
#   This allows LLM clients to send "10" for int parameters, which gets coerced correctly
# - tool_serializer: Custom serializer to handle string returns correctly and prevent double-serialization
#
# Reference: https://docs.glama.ai/fastmcp/servers/tools#input-validation-modes
mcp = FastMCP(
    "SEO MCP",
    strict_input_validation=False,
    tool_serializer=custom_serializer
)

# CapSolver website: https://dashboard.capsolver.com/passport/register?inviteCode=1dTH7WQSfHD0
# Get API Key from environment variable - must be set for production use
api_key = os.environ.get("CAPSOLVER_API_KEY")


def get_capsolver_token(site_url: str) -> Optional[str]:
    """
    Use CapSolver to solve the captcha and get a token
    
    Args:
        site_url: Site URL to query
        
    Returns:
        Verification token or None if failed
    """
    if not api_key:
        return None
    
    payload = {
        "clientKey": api_key,
        "task": {
            "type": 'AntiTurnstileTaskProxyLess',
            "websiteKey": "0x4AAAAAAAAzi9ITzSN9xKMi",  # site key of your target site: ahrefs.com,
            "websiteURL": site_url,
            "metadata": {
                "action": ""  # optional
            }
        }
    }
    res = requests.post("https://api.capsolver.com/createTask", json=payload)
    resp = res.json()
    task_id = resp.get("taskId")
    if not task_id:
        return None
 
    while True:
        time.sleep(1)  # delay
        payload = {"clientKey": api_key, "taskId": task_id}
        res = requests.post("https://api.capsolver.com/getTaskResult", json=payload)
        resp = res.json()
        status = resp.get("status")
        if status == "ready":
            token = resp.get("solution", {}).get('token')
            return token
        if status == "failed" or resp.get("errorId"):
            return None


@mcp.tool()
def get_backlinks_list(domain: str) -> Optional[Dict[str, Any]]:
    """
    Get backlinks list for the specified domain
    Args:
        domain (str): The domain to query
    Returns:
        List of backlinks for the domain, containing title, URL, domain rating, etc.
    """
    # Try to get signature from cache
    signature, valid_until, overview_data = load_signature_from_cache(domain)
    
    # If no valid signature in cache, get a new one
    if not signature or not valid_until:
        # Step 1: Get token
        site_url = f"https://ahrefs.com/backlink-checker/?input={domain}&mode=subdomains"
        token = get_capsolver_token(site_url)
        if not token:
            raise Exception(f"Failed to get verification token for domain: {domain}")
        
        # Step 2: Get signature and validUntil
        signature, valid_until, overview_data = get_signature_and_overview(token, domain)
        if not signature or not valid_until:
            raise Exception(f"Failed to get signature for domain: {domain}")
    
    # Step 3: Get backlinks list
    backlinks = get_backlinks(signature, valid_until, domain)
    return {
        "overview": overview_data,
        "backlinks": backlinks
    }


@mcp.tool()
def keyword_generator(keyword: str, country: str = "us", search_engine: str = "Google") -> Dict[str, Any]:
    """
    Find keyword ideas and variations for the specified keyword.
    
    Args:
        keyword: The keyword to search for ideas
        country: Country code (default: us)
        search_engine: Search engine to use (default: Google)
    
    Returns:
        Structured keyword idea suggestions grouped by regular and question-based variants.
    """
    from seo_mcp.keywords import get_keyword_ideas
    
    try:
        site_url = f"https://ahrefs.com/keyword-generator/?country={country}&input={urllib.parse.quote(keyword)}"
        token = get_capsolver_token(site_url)
        if not token:
            return {
                "keyword": keyword,
                "country": country,
                "searchEngine": search_engine,
                "ideas": [],
                "questionIdeas": [],
                "all": [],
                "error": "verification_failed"
            }

        ideas = get_keyword_ideas(token, keyword, country, search_engine)
        if ideas:
            return ideas

        return {
            "keyword": keyword,
            "country": country,
            "searchEngine": search_engine,
            "ideas": [],
            "questionIdeas": [],
            "all": [],
            "error": "no_results"
        }
    except Exception as e:
        return {
            "keyword": keyword,
            "country": country,
            "searchEngine": search_engine,
            "ideas": [],
            "questionIdeas": [],
            "all": [],
            "error": str(e)
        }


@mcp.tool()
def get_traffic(domain_or_url: str, country: str = "None", mode: Literal["subdomains", "exact"] = "subdomains") -> Optional[Dict[str, Any]]:
    """
    Check the estimated search traffic for any website. 

    Args:
        domain_or_url (str): The domain or URL to query
        country (str): The country to query, default is "None"
        mode (["subdomains", "exact"]): The mode to use for the query
    Returns:
        Traffic data for the specified domain or URL
    """
    site_url = f"https://ahrefs.com/traffic-checker/?input={domain_or_url}&mode={mode}"
    token = get_capsolver_token(site_url)
    if not token:
        raise Exception(f"Failed to get verification token for domain: {domain_or_url}")
    return check_traffic(token, domain_or_url, mode, country)


@mcp.tool()
def keyword_difficulty(keyword: str, country: str = "us") -> Optional[Dict[str, Any]]:
    """
    Get keyword difficulty score and SERP analysis for a specific keyword.
    
    This tool analyzes how competitive a keyword is and what content currently ranks.
    Use this to evaluate keyword opportunity and understand the competitive landscape.
    
    Returns difficulty score (0-100), search volume context, and top 10 ranking pages with:
    - Page title and URL
    - Domain Rating (authority)
    - URL Rating (page authority)
    - Estimated traffic and keywords ranking
    
    Note: Use keyword_generator to find related keywords, use this to analyze competition.
    """
    site_url = f"https://ahrefs.com/keyword-difficulty/?country={country}&input={urllib.parse.quote(keyword)}"
    token = get_capsolver_token(site_url)
    if not token:
        raise Exception(f"Failed to get verification token for keyword: {keyword}")
    return get_keyword_difficulty(token, keyword, country)


def main():
    """Run the MCP server"""
    mcp.run()


if __name__ == "__main__":
    main()
