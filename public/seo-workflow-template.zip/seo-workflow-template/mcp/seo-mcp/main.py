from seo_mcp.server import main as server_main

def main():
    """Entry point for the backlinks-mcp package"""
    server_main()

if __name__ == "__main__":
    main()