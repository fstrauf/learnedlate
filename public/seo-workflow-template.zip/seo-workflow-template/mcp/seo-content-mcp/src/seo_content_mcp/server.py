"""SEO Content MCP Server - Main server implementation"""

import os
import json
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
from pydantic import BaseModel, Field

from .content_cleaner import ContentCleaner, format_cleaning_result
from .date_distributor import DateDistributor, format_date_analysis, format_date_fix


class SEOTools(str, Enum):
    """Available SEO content tools"""
    TEST_DISTRIBUTION = "seo_test_distribution"
    CLEAN_CONTENT = "seo_clean_content"
    VALIDATE_CONTENT = "seo_validate_content"
    ANALYZE_DATES = "seo_analyze_dates"
    FIX_DATES = "seo_fix_dates"


class DistributionResult(BaseModel):
    """Result of a date distribution test"""
    project_name: str
    article_count: int
    earliest_date: str
    today_date: str
    days_available: int
    days_per_article: int
    distribution: list[dict[str, Any]]


class SEOContentServer:
    """Server for SEO content management operations"""
    
    def __init__(self, workspace_root: str | None = None):
        """Initialize the server with workspace root path"""
        self.workspace_root = workspace_root or os.getcwd()
        self.cleaner = ContentCleaner(self.workspace_root)
        self.distributor = DateDistributor(self.workspace_root)
        
    def test_distribution(
        self,
        project_name: str,
        article_count: int,
        earliest_date: str
    ) -> DistributionResult:
        """
        Test date distribution for articles without making changes.
        
        This demonstrates how articles would be distributed across the date range
        from earliest_date to today, ensuring even spacing and no clustering.
        
        Args:
            project_name: Name of the project (e.g., "Coffee", "Expense")
            article_count: Number of articles to distribute
            earliest_date: Earliest date in YYYY-MM-DD format
            
        Returns:
            DistributionResult with preview of how articles would be distributed
        """
        # Parse dates
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        earliest = datetime.strptime(earliest_date, '%Y-%m-%d')
        earliest = earliest.replace(hour=0, minute=0, second=0, microsecond=0)
        
        # Calculate distribution
        days_available = (today - earliest).days + 1
        days_per_article = max(1, days_available // article_count)
        
        # Generate distribution
        distribution = []
        
        # Show representative samples (first 5, middle, last 5)
        show_indices = self._get_sample_indices(article_count)
        
        for index in show_indices:
            days_offset = index * days_per_article
            article_date = earliest + timedelta(days=days_offset)
            
            # Cap at today
            if article_date > today:
                article_date = today
            
            marker = ""
            if index == 0:
                marker = " (first)"
            elif index == article_count - 1:
                marker = " (last)"
            elif index == article_count // 2:
                marker = " (middle)"
                
            distribution.append({
                "article_number": index + 1,
                "date": article_date.strftime('%Y-%m-%d'),
                "marker": marker.strip() if marker else None
            })
        
        # Add ellipsis indicator if we're showing a subset
        if len(show_indices) < article_count:
            middle_idx = len(distribution) // 2
            distribution.insert(middle_idx, {
                "article_number": None,
                "date": "...",
                "marker": f"({article_count - len(show_indices)} more articles)"
            })
        
        return DistributionResult(
            project_name=project_name,
            article_count=article_count,
            earliest_date=earliest_date,
            today_date=today.strftime('%Y-%m-%d'),
            days_available=days_available,
            days_per_article=days_per_article,
            distribution=distribution
        )
    
    def _get_sample_indices(self, article_count: int) -> list[int]:
        """
        Get sample indices to show in distribution.
        Shows first 5, middle, and last 5 articles.
        """
        if article_count <= 12:
            # Show all if small
            return list(range(article_count))
        
        indices = set()
        
        # First 5
        for i in range(min(5, article_count)):
            indices.add(i)
        
        # Middle
        indices.add(article_count // 2)
        
        # Last 5
        for i in range(max(0, article_count - 5), article_count):
            indices.add(i)
        
        return sorted(list(indices))


def format_distribution_result(result: DistributionResult) -> str:
    """Format distribution result as readable text"""
    lines = [
        f"📊 {result.project_name} Distribution Test ({result.article_count} articles)",
        "=" * 60,
        "",
        f"  Earliest date: {result.earliest_date}",
        f"  Today: {result.today_date}",
        f"  Total days available: {result.days_available} days",
        f"  Days per article: {result.days_per_article} days",
        f"  Date range: {result.earliest_date} → {result.today_date}",
        "",
        "  Distribution:",
        ""
    ]
    
    for item in result.distribution:
        if item["article_number"] is None:
            # Ellipsis
            lines.append(f"    {item['date']}")
            if item['marker']:
                lines.append(f"    {item['marker']}")
        else:
            marker = f" {item['marker']}" if item['marker'] else ""
            lines.append(f"    Article {item['article_number']}: {item['date']}{marker}")
    
    lines.extend([
        "",
        "✅ Articles are spread evenly across the full date range!",
        "   Instead of clustering, they're distributed proportionally.",
    ])
    
    return "\n".join(lines)


def detect_workspace_root() -> str:
    """
    Detect the workspace root directory by checking common locations.
    
    Priority:
    1. WORKSPACE_ROOT environment variable
    2. Look for 'general/days_to_expiry' or 'general/coffee' directory up the tree
    3. Current working directory
    4. Parent directory of the MCP script
    """
    # First, check environment variable
    if "WORKSPACE_ROOT" in os.environ:
        root = os.environ["WORKSPACE_ROOT"]
        if os.path.isdir(root):
            return root
    
    # Try to find the automation workspace by looking for telltale directories
    current = Path.cwd()
    for _ in range(5):  # Look up to 5 levels up
        if (current / "general" / "days_to_expiry").exists() or \
           (current / "general" / "coffee").exists() or \
           (current / "general" / "expense").exists():
            return str(current)
        current = current.parent
    
    # Try the MCP server directory's parent path
    mcp_dir = Path(__file__).parent.parent.parent.parent  # src/seo_content_mcp -> seo-content-mcp
    workspace_check = mcp_dir.parent  # Go to /mcp level
    if (workspace_check / "general" / "days_to_expiry").exists():
        return str(workspace_check)
    
    # Default to current working directory
    return os.getcwd()


async def serve() -> None:
    """Run the SEO Content MCP server"""
    server = Server("seo-content-mcp")
    
    # Get workspace root using intelligent detection
    workspace_root = detect_workspace_root()
    seo_server = SEOContentServer(workspace_root)

    
    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List available SEO content tools"""
        return [
            Tool(
                name=SEOTools.TEST_DISTRIBUTION,
                description=(
                    "Test date distribution for articles without making changes. "
                    "Shows how articles would be spread across dates from earliest_date to today. "
                    "Useful for previewing distribution before applying changes."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_name": {
                            "type": "string",
                            "description": "Name of the project (e.g., 'Coffee', 'Expense', 'Days to Expiry')"
                        },
                        "article_count": {
                            "type": "integer",
                            "description": "Number of articles to distribute",
                            "minimum": 1
                        },
                        "earliest_date": {
                            "type": "string",
                            "description": "Earliest date in YYYY-MM-DD format",
                            "pattern": "^\\d{4}-\\d{2}-\\d{2}$"
                        }
                    },
                    "required": ["project_name", "article_count", "earliest_date"]
                }
            ),
            Tool(
                name=SEOTools.CLEAN_CONTENT,
                description=(
                    "Clean content files by removing duplicate title headings and syncing dates "
                    "between articles.json and markdown frontmatter. Makes actual changes to files."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "website_path": {
                            "type": "string",
                            "description": "Relative path to website folder (e.g., 'general/coffee', 'general/expense')"
                        }
                    },
                    "required": ["website_path"]
                }
            ),
            Tool(
                name=SEOTools.VALIDATE_CONTENT,
                description=(
                    "Validate content files without making changes. Reports issues like "
                    "duplicate title headings, date mismatches, and missing frontmatter. "
                    "Use this before seo_clean_content to preview what would be fixed."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "website_path": {
                            "type": "string",
                            "description": "Relative path to website folder (e.g., 'general/coffee', 'general/expense')"
                        }
                    },
                    "required": ["website_path"]
                }
            ),
            Tool(
                name=SEOTools.ANALYZE_DATES,
                description=(
                    "Analyze article dates to find issues without making changes. "
                    "Detects future dates, overlapping dates (multiple articles on same day), "
                    "and poor distribution in recently created articles (last 7 days). "
                    "Use this before seo_fix_dates to see what would be changed."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "website_path": {
                            "type": "string",
                            "description": "Relative path to website folder (e.g., 'general/coffee', 'general/expense')"
                        }
                    },
                    "required": ["website_path"]
                }
            ),
            Tool(
                name=SEOTools.FIX_DATES,
                description=(
                    "Fix article date issues by redistributing recent articles (last 7 days). "
                    "Removes future dates, eliminates overlapping dates, and ensures even distribution. "
                    "Only affects recently created articles; leaves historical articles untouched. "
                    "Makes actual changes to articles.json file."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "website_path": {
                            "type": "string",
                            "description": "Relative path to website folder (e.g., 'general/coffee', 'general/expense')"
                        }
                    },
                    "required": ["website_path"]
                }
            )
        ]
    
    @server.call_tool()
    async def call_tool(name: str, arguments: Any) -> list[TextContent]:
        """Handle tool calls"""
        try:
            if name == SEOTools.TEST_DISTRIBUTION:
                result = seo_server.test_distribution(
                    project_name=arguments["project_name"],
                    article_count=arguments["article_count"],
                    earliest_date=arguments["earliest_date"]
                )
                
                formatted_output = format_distribution_result(result)
                
                return [
                    TextContent(
                        type="text",
                        text=formatted_output
                    )
                ]
            
            elif name == SEOTools.CLEAN_CONTENT:
                result = seo_server.cleaner.clean_website(
                    website_path=arguments["website_path"],
                    dry_run=False
                )
                
                formatted_output = format_cleaning_result(result)
                
                return [
                    TextContent(
                        type="text",
                        text=formatted_output
                    )
                ]
            
            elif name == SEOTools.VALIDATE_CONTENT:
                result = seo_server.cleaner.clean_website(
                    website_path=arguments["website_path"],
                    dry_run=True
                )
                
                formatted_output = format_cleaning_result(result)
                
                return [
                    TextContent(
                        type="text",
                        text=formatted_output
                    )
                ]
            
            elif name == SEOTools.ANALYZE_DATES:
                result = seo_server.distributor.analyze_dates(
                    website_path=arguments["website_path"]
                )
                
                formatted_output = format_date_analysis(result)
                
                return [
                    TextContent(
                        type="text",
                        text=formatted_output
                    )
                ]
            
            elif name == SEOTools.FIX_DATES:
                result = seo_server.distributor.fix_dates(
                    website_path=arguments["website_path"],
                    dry_run=False
                )
                
                formatted_output = format_date_fix(result, dry_run=False)
                
                return [
                    TextContent(
                        type="text",
                        text=formatted_output
                    )
                ]
            
            else:
                return [
                    TextContent(
                        type="text",
                        text=f"Unknown tool: {name}"
                    )
                ]
                
        except Exception as e:
            return [
                TextContent(
                    type="text",
                    text=f"Error executing {name}: {str(e)}"
                )
            ]
    
    # Run the server
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def main():
    """Main entry point"""
    import asyncio
    asyncio.run(serve())


if __name__ == "__main__":
    main()
