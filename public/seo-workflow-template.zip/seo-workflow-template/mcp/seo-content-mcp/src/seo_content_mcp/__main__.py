"""Entry point for the SEO Content MCP server."""

from .server import main

if __name__ == "__main__":
    main()
