# SEO Content MCP Server

A Model Context Protocol (MCP) server for managing SEO content lifecycle, including:
- Article synchronization with articles.json
- Smart date distribution to avoid clustering
- Content quality validation and cleaning
- Batch operations across multiple websites

## Features

### ✅ Test Distribution (Read-only)
- Preview how articles would be distributed across dates
- Test different scenarios without making changes
- Visualize distribution patterns

### ✅ Content Quality
- **Validate Content** - Check for issues without making changes
- **Clean Content** - Fix duplicate title headings and date mismatches
- Sync dates between articles.json and markdown frontmatter
- Remove duplicate H1 headings that match the title

### Article Sync (Coming soon)
- Sync articles.json with markdown content files
- Extract frontmatter metadata
- Update word counts and dates

### Date Distribution (Coming soon)
- Analyze article dates for issues
- Fix future dates and overlapping dates
- Smart redistribution of recent articles

## Installation

```bash
cd mcp/seo-content-mcp
uv sync
```

## Usage

Add to your MCP settings (Claude Desktop or your MCP client):

```json
{
  "mcpServers": {
    "seo-content": {
      "command": "uv",
      "args": [
        "--directory",
        "/Users/fstrauf/01_code/automation/mcp/seo-content-mcp",
        "run",
        "seo-content-mcp"
      ],
      "env": {
        "WORKSPACE_ROOT": "/Users/fstrauf/01_code/automation"
      }
    }
  }
}
```

Or copy the configuration from `claude_desktop_config.json`.

## Tools

### `seo_test_distribution`
Test date distribution for articles without making changes.

**Arguments:**
- `project_name` (string): Name of the project (e.g., "coffee", "expense")
- `article_count` (integer): Number of articles to distribute
- `earliest_date` (string): Earliest date in YYYY-MM-DD format

**Returns:** Distribution preview showing how articles would be spread across dates

### `seo_validate_content`
Validate content files without making changes. Reports issues found.

**Arguments:**
- `website_path` (string): Relative path to website (e.g., "general/coffee")

**Returns:** Validation report showing:
- Duplicate title headings (H1 that matches frontmatter title)
- Date mismatches between articles.json and markdown frontmatter
- Missing frontmatter

### `seo_clean_content`
Clean content files by fixing issues. **Makes actual file changes.**

**Arguments:**
- `website_path` (string): Relative path to website (e.g., "general/coffee")

**Returns:** Cleaning report showing what was fixed:
- Removes duplicate title headings
- Syncs dates from articles.json to markdown frontmatter
- Reports number of issues fixed

### `seo_analyze_dates`
Analyze article dates to find issues without making changes.

**Arguments:**
- `website_path` (string): Relative path to website (e.g., "general/coffee")

**Returns:** Analysis report showing:
- Total, past, and recent article counts
- Date issues (future dates, missing dates, invalid formats)
- Overlapping dates (multiple articles on same day)
- Recent article date range and distribution

### `seo_fix_dates`
Fix date issues by redistributing recent articles. **Makes actual file changes.**

**Arguments:**
- `website_path` (string): Relative path to website (e.g., "general/coffee")

**Returns:** Fix report showing:
- Number of articles fixed
- Before/after dates for each change
- New distribution details (range, spacing, uniqueness)
- Only affects articles from last 7 days

## Development

```bash
# Install in development mode
pip install -e .

# Run the server
seo-content-mcp
```

## License

MIT
