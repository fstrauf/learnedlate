# SEO Workflow System

Create, organize, and publish SEO content in 4 steps using AI.

## Prerequisites

- **Python 3.10+** (check with `python --version`)
- **pip or uv** (for installing MCP dependencies)
- **GitHub Copilot** (free tier available)

## Quick Start (13 Minutes)

```bash
chmod +x setup.sh
./setup.sh
```

Answer 3 questions. Everything is set up automatically:
- Project name
- Website URL

**Note:** `setup.sh` will automatically detect and use `uv` (fastest) or `pip` to install MCP dependencies. If you don't have Python installed, install it first:
- **macOS/Linux:** `brew install python@3.11`
- **Windows:** Download from [python.org](https://python.org)
- **Optional (for faster installs):** `pip install uv`

Then copy the GitHub Copilot config lines and restart Copilot. You're ready to work.

---
- CapSolver API key (optional)

The script installs MCP dependencies and creates your project structure.

Then copy 5 lines into your GitHub Copilot config and restart.

You're ready to work.

---

## The 4 Steps

All automated through AI prompts.

### Step 1: Research Keywords
```
Open: .github/prompts/seo1-[project].prompt.md
Use: Type "/" in GitHub Copilot and select the prompt
Result: Keywords researched, articles.json updated
```

### Step 2: Create Articles
```
Open: .github/prompts/seo2-[project].prompt.md
Use: Type "/" in GitHub Copilot and select the prompt
Result: Articles drafted and written to content/ folder
```

### Step 3: Link Articles
```
Open: .github/prompts/seo3-[project].prompt.md
Use: Type "/" in GitHub Copilot and select the prompt
Result: Internal links added to articles.json
```

### Step 4: Validate & Cleanup
```
Open: .github/prompts/seo4-[project].prompt.md
Use: Type "/" in GitHub Copilot and select the prompt
Result: Content validated, dates distributed, ready to publish
```

---

## Your Files

After `setup.sh`, you'll have:

```
general/[your-project]/
├── [project].md                         # Project overview (you edit)
├── [project]_seo_content_brief.md       # Content strategy (auto-updated by prompts)
├── articles.json                        # Master list of all articles
├── manifest.json                        # Project metadata
└── content/
    ├── 01_article.md
    ├── 02_article.md
    └── ...
```

**What you edit:**
- `[project].md` - **Maintain this file** (Add your project details, brand voice, website info — the prompts reference this constantly)
- `content/*.md` - Write/edit articles
- `articles.json` - Review what was created (don't edit manually)

---

## Maintaining Your Project File

The `[project].md` file (e.g., `real-estate.md`) is **critical** to the workflow.

This file is your project's source of truth. It contains:
- Your website/project details
- Brand voice and tone
- Context for content creation
- Any specific guidelines

**The prompts read this file and use it to:**
- Generate aligned content
- Maintain consistent brand voice
- Make better keyword decisions
- Create relevant internal links

**Keep it updated as you work.** When you refine your strategy, update the file so the next prompts reflect your latest thinking.

---

## GitHub Copilot Setup (3 min)

After running `setup.sh`, you'll see instructions.

Copy the lines from `config/copilot_mcp_config.template.md`.

Paste into your `~/.copilot/config.toml` (or wherever Copilot stores config).

Restart GitHub Copilot.

Then you're ready — open any prompt file and type `/` in Copilot to run it.

---

## Adding Another Project

```bash
./setup.sh
```

Run it again, answer with a different project name.

Each project is separate.

---

## Working with Articles

**articles.json structure:**
```json
{
  "articles": [
    {
      "id": 1,
      "title": "Article Title",
      "url_slug": "article-title",
      "status": "published",
      "date_published": "2025-11-12",
      "word_count": 2500,
      "related_articles": [2, 3, 5]
    }
  ]
}
```

The prompts auto-update this. You mostly just reference it.

**Folder structure:**
- 1 article = 1 file
- Filename: `01_article-title.md`, `02_another-article.md`, etc.
- Markdown files live in `content/` folder

---

## FAQ

**Q: How do I run the prompts in GitHub Copilot?**
A: Type `/` (forward slash) in GitHub Copilot and select the prompt file. No copy/paste needed — Copilot accesses them directly from `.github/prompts/`.

**Q: What if I have questions about the workflow?**
A: See `projects/seo/1-keyword_research.md`, `2-content_creation.md`, etc. for deeper explanations.

**Q: Can I edit the prompts?**
A: Yes. Edit `.github/prompts/seo[1-4]-[project].prompt.md` as needed. They're designed to be modified.

**Q: What if a prompt fails?**
A: Usually means the folder structure changed or MCPs aren't installed. Check:
1. MCPs installed: Check GitHub Copilot logs
2. Config correct: Verify Copilot config has MCP paths
3. Project folder exists: `general/[project]/` should exist

**Q: Can I skip steps?**
A: Not recommended. They build on each other. But you can run them in any order if needed.

**Q: How do I add more articles manually?**
A: Create a markdown file in `content/` (e.g., `10_my-article.md`). Update `articles.json` with an entry for it.

**Q: Can I use this for multiple websites?**
A: Yes. Run `setup.sh` multiple times with different project names. Each is independent.

**Q: What's the CapSolver API key for?**
A: Optional. Used by SEO MCP to fetch real traffic data. Skip if you don't want it.

---

## Examples

The `general/example_project/` folder shows what a completed project looks like.

Reference it when:
- Understanding folder structure
- Checking `articles.json` format
- Seeing what finished articles look like

---

## That's It

Download → Run setup → Link MCPs → Start working.

The prompts guide you through the rest.
