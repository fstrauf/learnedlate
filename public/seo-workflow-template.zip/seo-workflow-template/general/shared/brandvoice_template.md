# Brand Voice Guide

## Your Brand Voice for [NICHE]

Update this based on your brand personality and audience.

### Core Characteristics

1. **Tone**
   - Professional but approachable
   - Clear and direct language
   - Practical over theoretical

2. **Style**
   - Short paragraphs for readability
   - Active voice preferred
   - Real examples, not abstract concepts
   - Conversational questions to engage readers

3. **Values**
   - Actionable advice
   - Honest and transparent
   - Data-driven when relevant
   - Reader-focused

### Writing Guidelines

- **Headings**: Clear and compelling
- **Examples**: Specific and relevant to [NICHE]
- **Structure**: Logical flow, easy to scan
- **Vocabulary**: Standard terminology from [NICHE], avoid jargon

### Your Niche: [NICHE]

Audience: [Describe your target audience]

Key messages: [What do you want them to know?]

Avoid: [What tone/messages don't fit your brand?]
