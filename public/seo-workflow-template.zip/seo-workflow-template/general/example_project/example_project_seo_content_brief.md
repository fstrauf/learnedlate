# Example Project - Content Brief

**Website:** example-coffee-blog.com
**Niche:** Coffee Industry
**Created:** 2025-11-12

## Content Strategy

### Target Audience

Home coffee enthusiasts who want to improve their brewing skills and knowledge.

### Key Topics & Pillars

1. Coffee Brewing Methods - Techniques and processes
2. Coffee Bean Types - Origins and varieties
3. Coffee Equipment - Tools and recommendations
4. Coffee Culture - History and trends

### Content Goals

- Primary: Become a resource for home coffee brewers
- Secondary: Drive affiliate traffic for coffee equipment

### Publishing Plan

2-3 articles per month. Focus on seasonal content.

---

## Article Ideas

3 published articles covering the main pillars.

See articles.json for full list.

---

## SEO Strategy

### Target Keywords

- how to brew coffee (2000 monthly searches)
- types of coffee beans (1500 monthly searches)
- coffee brewing equipment (1200 monthly searches)

### Keyword Clusters

**Cluster 1: Brewing Methods**
- Pillar: How to Brew the Perfect Cup
- Support: Brewing techniques for specific methods

**Cluster 2: Coffee Types**
- Pillar: Coffee Bean Types and Origins
- Support: Regional varieties and characteristics

**Cluster 3: Equipment**
- Pillar: Essential Coffee Equipment Guide
- Support: Equipment reviews and comparisons

---

## Progress Tracker

| Phase | Status | Articles | Notes |
|-------|--------|----------|-------|
| Research | ✓ | 3 | Initial research completed |
| Creation | ✓ | 3 | All 3 articles written |
| Linking | ✓ | 3 | Internal links established |
| Cleanup | ✓ | 3 | All validated and published |

---

## Brand Voice

See `general/shared/brandvoice_template.md` for brand guidelines.
