# Example Project - Coffee

**Website:** example-coffee-blog.com
**Niche:** Coffee Industry
**Status:** Example only - reference for structure

## Project Overview

This is an example project showing how the SEO workflow system works.

### Target Audience

Coffee enthusiasts, home brewers, and professionals interested in specialty coffee.

### Key Topics

1. Coffee brewing methods
2. Coffee types and origins
3. Coffee equipment
4. Coffee business/careers

### Publishing Schedule

Monthly content releases with regular updates.

---

See `example_project_seo_content_brief.md` for the full content strategy.
