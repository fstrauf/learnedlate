# How to Brew the Perfect Cup of Coffee

Learn the fundamentals of brewing excellent coffee at home.

## Introduction

Making great coffee starts with understanding the basics. This guide covers everything you need to know to brew a consistently delicious cup.

## Brewing Fundamentals

### Water Temperature

The ideal water temperature is between 195-205°F (90-96°C). This ensures proper extraction without burning the beans.

### Brew Time

Different methods require different brew times:
- French Press: 4 minutes
- Pour Over: 2-3 minutes
- Espresso: 25-30 seconds

### Coffee-to-Water Ratio

A standard ratio is 1:16 (1 gram coffee to 16 grams water). Adjust to taste.

## Popular Brewing Methods

### Pour Over

Simple, forgiving, and produces excellent results.

1. Use a pour over cone or Chemex
2. Add a paper filter
3. Rinse with hot water
4. Add ground coffee
5. Pour slowly in circular motions
6. Total brew time: 2-3 minutes

### French Press

Produces a rich, full-bodied coffee.

1. Heat water to 195-205°F
2. Add coarsely ground coffee
3. Pour hot water over grounds
4. Steep for 4 minutes
5. Press down the plunger
6. Serve immediately

### Espresso

Requires an espresso machine but produces concentrated, intense coffee.

1. Grind finely
2. Tamp firmly and evenly
3. Pull shot for 25-30 seconds
4. Results in 1-2 oz of espresso

## Conclusion

Great coffee comes down to three things: fresh beans, proper temperature, and the right technique. Start with these basics and adjust based on your preferences.

---

**Related Articles:** See articles.json for links to Coffee Bean Types and Equipment Guide.

**Last Updated:** 2025-11-12
