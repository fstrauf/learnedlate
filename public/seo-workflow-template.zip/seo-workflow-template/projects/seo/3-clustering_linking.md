# SEO Clustering & Linking - AI Instructions

⚠️ **EXECUTION MANDATE**: Do NOT ask questions, summarize, or provide options. Execute this workflow immediately and completely.

You are an SEO strategist. This workflow organizes content into topical clusters and adds internal links to establish topical authority.

## Project Structure
- Project folder: `/Users/fstrauf/01_code/automation/general/[PROJECT_NAME]/`
- Content brief: `[PROJECT_NAME]_seo_content_brief.md`
- Articles JSON: `articles.json` (all articles with metadata)
- Content folder: `content/` (where articles are stored)

## When to Use
- **After keyword research** - To organize discovered keywords into clusters
- **After content creation** - To link existing articles together
- **During content audit** - To identify gaps and cannibalization

---

## PART 1: Create Clusters

### 1. Read Articles JSON
Load all articles with their keywords and intent types.

### 2. Group by Intent
Group articles that share a common search intent:
- **Informational**: "Teach me" (guides, explanations)
- **Navigational**: "Show me the best" (comparisons, lists)
- **Transactional**: "Help me do" (how-to, step-by-step)
- **Commercial**: "Where to buy/get" (deals, recommendations)

Typical project has 3-4 clusters.

### 3. Choose Pillar Articles
For each cluster, select ONE pillar article:
- **Broadest scope** (covers 3+ subtopics)
- **Hub for all related content** (links to all supports)
- Example: "How to Store Coffee Beans" (pillar) vs "Why Roast Date Matters" (support)

### 4. Identify Support Articles
All other articles in cluster are supports:
- **Narrow focus** (1 specific subtopic)
- **Link to pillar** for broader context

### 5. Map Content Coverage
For each cluster, document:
- **Primary Intent**: What users search for
- **Covered (✅)**: Topics already addressed by articles
- **Missing (⚠️)**: Content gaps with priority (HIGH/MEDIUM/LOW)

Calculate gap priority: (Volume × 1/KD × Unique Angle)
- Score > 50 = HIGH
- Score 10-50 = MEDIUM  
- Score < 10 = LOW

### 6. Check for Cannibalization
Ensure no two articles target the same keyword:
- ✅ Different keywords = distinct content
- ⚠️ Same keyword = merge or differentiate

### 7. Update Content Brief
Add "Topical Clusters & Intent Mapping" section:

```markdown
## Topical Clusters & Intent Mapping

### Cluster 1: [Name] ⭐ PILLAR CLUSTER
**Primary Intent:** "[What users want to learn/do]"

**Pillar Article:**
- **"[Title]"** (ID: [#])
  - Target Keyword: `[keyword]`
  - Scope: [What this covers]

**Support Articles:**
| Article | Target Keyword | Intent Type | Focus |
|---------|---|---|---|
| "[Title]" (ID: [#]) | `[keyword]` | [Type] | [What it covers] |

**Secondary Intents COVERED:**
✅ [Topic 1]
✅ [Topic 2]

**Secondary Intents MISSING (Content Gaps):**
⚠️ **"[Gap Title]"** (Est. [vol] vol, KD: [#]) - [HIGH/MEDIUM/LOW] priority
  - [What to cover]

**Linking Strategy:**
- Pillar ←→ All supports
- Cross-cluster: Link to [other cluster] when mentioning [topic]
```

Repeat for each cluster.

---

## PART 2: Add Internal Links

### 1. Create Linking Checklist
In content brief, add "Internal Linking Strategy - Checklist" section:

```markdown
## Internal Linking Strategy - Checklist

### Cluster 1: [Name] Hub & Spokes

**Hub: [Pillar Title] (ID: [#]) - Link to all:**
- ☐ [Support 1] (ID: [#])
- ☐ [Support 2] (ID: [#])
- ☐ Cross-cluster: [Related article] (ID: [#])

**[Support 1 Title] (ID: [#]) - Link to:**
- ☐ Hub: [Pillar] (ID: [#])
- ☐ [Support 2] (ID: [#])
```

### 2. Add Links to Articles
For each unchecked (☐) link in checklist:

**Open the article markdown file** in `content/` folder.

**Add inline links** where topic naturally fits:
```markdown
Learn more about [topic](./related-article.md) to understand...
```

**Add related articles section** at bottom:
```markdown
---

## Related Articles

- [Article Title](./article-filename.md)
- [Another Article](./another-filename.md)
```

**Use descriptive link text:**
- ✅ Good: `[How to store coffee beans](./storage-guide.md)`
- ❌ Bad: `[click here](./storage-guide.md)`

**Keep it natural:**
- Max 3-5 inline links per article
- Use relative paths: `./filename.md`

### 3. Mark as Done
After adding each link, go to content brief and change:
- `☐` → `✅`

### 4. Bidirectional Linking
Ensure both directions exist:
- If Article A links to B → Article B should link to A

---

## Usage

```
Project: [PROJECT_NAME]
Brief: /Users/fstrauf/01_code/automation/general/[PROJECT_NAME]/[PROJECT_NAME]_seo_content_brief.md
Articles: /Users/fstrauf/01_code/automation/general/[PROJECT_NAME]/articles.json

Create clusters from articles.json. Update content brief with clusters and linking checklist. Add links to article files. Mark checklist items completed.
```

---

## Validation Checklist

Before finishing:
- ✅ Each cluster has 1 pillar + 2-4 supports
- ✅ No keyword cannibalization (distinct keywords)
- ✅ Pillar is broadest, supports are narrower
- ✅ 3-5 content gaps identified per cluster
- ✅ Gaps prioritized (HIGH/MEDIUM/LOW)
- ✅ Linking checklist created
- ✅ Links added to article files
- ✅ All checklist items marked ✅
- ✅ Bidirectional links exist (A→B and B→A)

---

## Output Summary

After completion, provide:
1. **Clusters created**: [Number] clusters identified
2. **Gaps found**: [Number] HIGH priority gaps
3. **Files modified**: List of article files updated with links
4. **Checklist status**: [X] of [Y] links added
5. **Issues**: Any cannibalization or missing files noted
