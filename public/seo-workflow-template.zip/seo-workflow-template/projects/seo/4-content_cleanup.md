# SEO Workflow Step 4: Content Cleanup & Quality Assurance

## Overview

This step ensures all content is properly formatted, dated, and ready for publication. It uses automated tools to validate content structure, fix common issues, and optimize date distribution.

## Prerequisites

- ✅ Articles created (Step 2)
- ✅ Clustering & linking complete (Step 3)
- ✅ articles.json exists
- ✅ Content files in content/ folder

## Tools Used

This workflow uses the **SEO Content MCP** tools for automated cleanup and validation.

---

## Step 1: Content Validation

**Objective:** Check all content files for common issues without making changes.

### Actions:

1. **Validate content structure:**
   ```
   Use: seo_validate_content
   Args: website_path = "general/{project_name}"
   ```
   
   This checks for:
   - Duplicate title headings (H1 matching frontmatter title)
   - Date mismatches between articles.json and markdown
   - Missing frontmatter fields
   - Structural issues

2. **Review the report:**
   - Note any duplicate headings found
   - Check date mismatches
   - Identify missing frontmatter

3. **Document issues:**
   - Keep track of issue counts by type
   - Note which files need attention

---

## Step 2: Content Cleaning

**Objective:** Fix identified issues automatically.

### Actions:

1. **Clean content files:**
   ```
   Use: seo_clean_content
   Args: website_path = "general/{project_name}"
   ```
   
   This automatically:
   - Removes duplicate H1 headings that match the title
   - Syncs dates from articles.json to markdown frontmatter
   - Updates or adds missing date fields

2. **Verify fixes:**
   - Re-run `seo_validate_content` to confirm all issues resolved
   - Should show "No issues found"

---

## Step 3: Date Analysis

**Objective:** Identify date distribution issues in recent articles.

### Actions:

1. **Analyze article dates:**
   ```
   Use: seo_analyze_dates
   Args: website_path = "general/{project_name}"
   ```
   
   This checks for:
   - Future dates (articles scheduled beyond today)
   - Overlapping dates (multiple articles on same day)
   - Missing or invalid published_date fields
   - Poor distribution in recent articles (last 7 days)

2. **Review findings:**
   - Check total articles vs recent articles
   - Note any future dates
   - Identify overlapping dates
   - Review date range and span

3. **Assess distribution quality:**
   - Are recent articles clustered together?
   - Do any articles share the same date?
   - Are there any dates in the future?

---

## Step 4: Date Distribution Optimization

**Objective:** Fix date issues and ensure even distribution.

### Actions:

1. **Fix date issues:**
   ```
   Use: seo_fix_dates
   Args: website_path = "general/{project_name}"
   ```
   
   This automatically:
   - Caps future dates at today
   - Eliminates same-day overlaps
   - Redistributes recent articles with proper spacing (minimum 2 days)
   - Preserves all historical article dates (older than 7 days)

2. **Review changes:**
   - Check number of articles affected
   - Verify new date distribution (range and spacing)
   - Confirm unique dates (no overlaps)
   - Note the days-per-article spacing

3. **Validate fix:**
   - Re-run `seo_analyze_dates` to confirm no issues remain
   - Should show "No issues detected"

---

## Step 5: Distribution Preview

**Objective:** Visualize how all articles are distributed across time.

### Actions:

1. **Get article count and date range:**
   - Count total articles in articles.json
   - Find earliest published_date

2. **Test distribution:**
   ```
   Use: seo_test_distribution
   Args:
     project_name = "{Project Name}"
     article_count = {total articles}
     earliest_date = "{earliest published_date}"
   ```
   
   This shows:
   - Total days available
   - Days per article (spacing)
   - Sample distribution (first, middle, last articles)
   - Even spacing visualization

3. **Verify quality:**
   - Articles should be evenly spread
   - No clustering at specific dates
   - Consistent spacing throughout

---

## Step 6: Final Validation

**Objective:** Comprehensive check before publishing.

### Actions:

1. **Run all validations:**
   - `seo_validate_content` → Should be clean
   - `seo_analyze_dates` → Should have no issues
   
2. **Check articles.json:**
   - All articles have published_date
   - All articles have title, file, slug
   - Dates are in chronological order
   - No future dates
   - No duplicate dates

3. **Spot-check content files:**
   - Random sample of 3-5 markdown files
   - Verify frontmatter is complete
   - Check no duplicate H1 headings
   - Confirm dates match articles.json

---

## Expected Outcomes

After completing this workflow, you should have:

✅ **Clean Content:**
- No duplicate title headings
- Complete frontmatter on all files
- Dates synced between JSON and markdown

✅ **Optimized Dates:**
- No future dates
- No overlapping dates (same day)
- Even distribution with proper spacing
- Recent articles properly spaced (min 2 days)
- Historical articles untouched

✅ **Quality Assurance:**
- All validation checks pass
- Distribution preview shows even spread
- Ready for publication

---

## Troubleshooting

### Issue: Validation finds duplicate headings
**Solution:** Run `seo_clean_content` to automatically remove them

### Issue: Date mismatches between JSON and markdown
**Solution:** Run `seo_clean_content` to sync dates from articles.json

### Issue: Multiple articles on same date
**Solution:** Run `seo_fix_dates` to redistribute recent articles

### Issue: Future dates found
**Solution:** Run `seo_fix_dates` to cap dates at today

### Issue: Missing published_date fields
**Solution:** Manually add dates to articles.json, then run `seo_clean_content` to sync

---

## Workflow Integration

This step fits into the complete SEO workflow:

1. **Keyword Research** → Identify target keywords
2. **Content Creation** → Write articles
3. **Clustering & Linking** → Organize and interlink
4. **Content Cleanup** → ⭐ **YOU ARE HERE** ⭐
5. **Publishing** → Deploy to website
6. **Monitoring** → Track performance

---

## Best Practices

1. **Always validate before cleaning** - Know what will change
2. **Review date changes** - Understand the new distribution
3. **Preserve history** - Only recent articles (7 days) are affected
4. **Regular maintenance** - Run cleanup after each content batch
5. **Verify fixes** - Re-validate after each operation

---

## Notes

- Date fixing only affects articles from the **last 7 days**
- Historical articles (older than 7 days) are **never modified**
- Minimum spacing is **2 days** between articles
- All operations can be previewed before applying changes
- Content cleaning is **safe** - only removes duplicates and syncs dates

---

## Success Criteria

- ✅ All validation checks pass
- ✅ Zero duplicate title headings
- ✅ All dates synced and valid
- ✅ No overlapping dates
- ✅ Even distribution across time
- ✅ No future dates
- ✅ Ready for publication
