# SEO Workflow Template - Complete Package

**Version:** 1.0
**Last Updated:** 2025-11-12

## What's Included

This package contains everything needed to run the SEO workflow system.

### Core Files

- **README.md** - User guide and quick start
- **setup.sh** - Interactive setup script (creates projects, installs MCPs)
- **verify-setup.sh** - Verification script to check installation

### Folder Structure

```
seo-workflow-template/
├── README.md                           # 2-page user guide
├── setup.sh                            # Interactive setup
├── verify-setup.sh                     # Verification
│
├── .github/prompts/
│   ├── _seo1-template.prompt.md        # Keyword research (template)
│   ├── _seo2-template.prompt.md        # Content creation (template)
│   ├── _seo3-template.prompt.md        # Internal linking (template)
│   └── _seo4-template.prompt.md        # Content cleanup (template)
│
├── general/
│   ├── shared/
│   │   ├── ARTICLES_TEMPLATE.json
│   │   └── brandvoice_template.md
│   │
│   └── example_project/                # Working example
│       ├── example_project.md
│       ├── example_project_seo_content_brief.md
│       ├── articles.json
│       ├── manifest.json
│       └── content/
│           └── 01_perfect_cup.md
│
├── projects/seo/
│   ├── 1-keyword_research.md           # Workflow reference
│   ├── 2-content_creation.md           # Workflow reference
│   ├── 3-clustering_linking.md         # Workflow reference
│   ├── 4-content_cleanup.md            # Workflow reference
│   │
│   └── templates/
│       ├── content_brief_template.md
│       ├── article_template.md
│       └── manifest_template.json
│
├── mcp/
│   ├── seo-mcp/                        # SEO research tools
│   └── seo-content-mcp/                # Content management tools
│
└── config/
    ├── copilot_mcp_config.template.md    # MCP setup instructions
    └── setup-codex.sh                    # Helper for GitHub Copilot config
```

## Prerequisites

- **Python 3.10+** - Required for MCPs
- **pip or uv** - For dependency installation (setup.sh uses `uv` if available, falls back to `pip`)
- **GitHub Copilot** - For running prompts

## Quick Start

### 1. Run Setup (5 min)

```bash
chmod +x setup.sh
./setup.sh
```

Answer the prompts:
- Project name
- Website URL
- CapSolver API key (optional)

**What happens during setup:**
- Creates project folder structure
- Installs MCP dependencies (automatically via pip or uv)
- Generates 4 project-specific prompts
- Creates articles registry and content brief

### 2. Link MCPs in GitHub Copilot (3 min)

```bash
bash config/setup-codex.sh
```

Copy the output into `~/.copilot/config.toml` and restart GitHub Copilot.

### 3. Start Workflow

- Copy a prompt from `.github/prompts/seo[1-4]-[project].prompt.md`
- Paste into Codex
- Run it

That's it!

## Files You'll Edit

After setup, your project will be in `general/[project_name]/`:

- **[project].md** - **Project overview (maintain this file)** — Brand voice, project details, context. The prompts reference this constantly.
- **[project]_seo_content_brief.md** - Content strategy (auto-updated by prompts)
- **articles.json** - Master article list (auto-updated by prompts)
- **content/*.md** - Individual articles (you write/edit)

### Maintaining Your Project File

The `[project].md` file is your project's source of truth and **must be kept updated**:

- Contains your website details, brand voice, and strategy
- Used by all 4 prompts as the reference document
- Directly affects content quality and alignment

Keep it updated as your strategy evolves. The better your `.md` file, the better your prompts perform.

## The 4-Step Workflow

| Step | Prompt | Output |
|------|--------|--------|
| 1 | seo1-[project] | Keywords researched, articles.json populated |
| 2 | seo2-[project] | Articles drafted and written to content/ |
| 3 | seo3-[project] | Internal links added to articles |
| 4 | seo4-[project] | Content validated and cleanup applied |

## Understanding the Files

### .github/prompts/

The 4 prompts guide you through the entire workflow. These are templates - when you run `setup.sh`, it creates project-specific versions with names substituted.

Template prompts use placeholders: `[PROJECT_NAME]`, `[WEBSITE_URL]`

Actual prompts (after setup): `seo1-coffee.prompt.md`, `seo2-coffee.prompt.md`, etc.

### general/shared/

Shared templates used for all projects:
- **ARTICLES_TEMPLATE.json** - Empty articles registry
- **brandvoice_template.md** - Brand voice guide (customize per project)

### projects/seo/

Workflow reference files (referenced by prompts, not for reading):
- 1-keyword_research.md
- 2-content_creation.md
- 3-clustering_linking.md
- 4-content_cleanup.md

These are detailed instructions that the prompts reference.

### mcp/

Two MCPs that handle advanced features:
- **seo-mcp** - Keyword research, traffic data, competitor analysis
- **seo-content-mcp** - Content validation, date distribution, cleanup

## Example Project

`general/example_project/` shows what a completed project looks like:
- Project structure
- articles.json format
- Content files
- Content brief example

Reference this when building your own projects.

## Creating Another Project

Just run setup again:

```bash
./setup.sh
```

Each project is independent. No conflicts.

## FAQ

**Q: Can I skip the MCPs?**
A: Yes, but you'll lose advanced features (traffic data, validation). The prompts still work.

**Q: How do I customize the prompts?**
A: Edit `.github/prompts/seo[1-4]-[project].prompt.md` as needed. They're designed to be modified.

**Q: What if something breaks?**
A: Run `verify-setup.sh` to check your installation. Check GitHub Copilot logs for MCP errors.

**Q: Can I use this for multiple websites?**
A: Yes, run setup.sh multiple times with different project names.

## Support

- **Setup issues:** Check verify-setup.sh output
- **Copilot/MCP issues:** Check GitHub Copilot logs
- **Workflow questions:** See projects/seo/[1-4]-*.md files
- **File format issues:** Check general/example_project/ for examples

## What's Next

1. Verify setup: `bash verify-setup.sh`
2. Read: README.md (2 pages)
3. Run: `./setup.sh` to create your project
4. Copy prompt: `.github/prompts/seo1-[project].prompt.md`
5. Run workflow in GitHub Copilot

That's it. You're good to go.

---

**Ready to get started?**

```bash
./setup.sh
```
